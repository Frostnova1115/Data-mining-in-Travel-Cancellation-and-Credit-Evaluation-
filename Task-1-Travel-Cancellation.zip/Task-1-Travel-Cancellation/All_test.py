import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
import pandas as pd
import torch.utils.data as Data

device = (
    "cuda"
    if torch.cuda.is_available()
    else "mps"
    if torch.backends.mps.is_available()
    else "cpu"
)

train_data = pd.read_csv("train.csv", index_col='Index')
test_data = pd.read_csv("test.csv", index_col='Index')

x_train = torch.Tensor([list(train_data.loc[i, 'Attr1':'Attr17']) for i in
                        range(train_data.index[0], train_data.index[0] + len(train_data))])
y_train = torch.Tensor(
    [train_data.loc[i, 'Label'] for i in range(train_data.index[0], train_data.index[0] + len(train_data))]).type(
    torch.LongTensor)

x_answer = torch.Tensor(
    [list(test_data.loc[i, 'Attr1':'Attr17']) for i in range(test_data.index[0], test_data.index[0] + len(test_data))])


# y_test = torch.Tensor(
#     [test_data.loc[i, 'Label'] for i in range(test_data.index[0], test_data.index[0] + len(test_data))])


class NN(torch.nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(NN, self).__init__()
        self.hidden1 = nn.Linear(n_input, n_hidden)
        self.hidden2 = nn.Linear(n_hidden, n_hidden)
        self.hidden3 = nn.Linear(n_hidden, n_hidden)
        self.hidden4 = nn.Linear(n_hidden, n_hidden)
        self.hidden5 = nn.Linear(n_hidden, n_hidden)
        self.predict = nn.Linear(n_hidden, n_output)
        self.dropout = nn.Dropout(p=0.05)

    def forward(self, input_x):
        output = (F.relu(self.hidden1(input_x)))
        output = (F.relu(self.hidden2(output)))
        output = (F.relu(self.hidden3(output)))
        output = (F.relu(self.hidden4(output)))
        output = (F.relu(self.hidden5(output)))
        output = self.predict(output)
        # output = self.dropout(F.relu(self.hidden1(input_x)))
        # output = self.dropout(F.relu(self.hidden2(output)))
        # output = self.dropout(F.relu(self.hidden3(output)))
        # output = self.predict(output)
        # output = F.softmax(output,dim=0)
        return output


epochs = 1001
net = NN(len(x_train[0]), 64, 2)
loss_func = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(net.parameters(), lr=0.02)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, epochs // 6, 0.5)

for epoch in range(epochs):
    prediction = net(x_train)
    loss = loss_func(prediction, y_train)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    scheduler.step()
    if epoch % 50 == 0:
        print(epoch)
        print(optimizer.param_groups[0]['lr'])
        result = torch.max(F.softmax(prediction), 1)[1]
        pred_y = result.data.numpy().squeeze()
        target_y = y_train.data.numpy()
        print(loss, end='')
        # print('accuracy: ', sum(pred_y == target_y) / len(y))
        TP = sum([(pred_y[i] == target_y[i] and pred_y[i] == 1) for i in range(len(pred_y))])
        FP = sum([(pred_y[i] != target_y[i] and pred_y[i] == 1) for i in range(len(pred_y))])
        TN = sum([(pred_y[i] == target_y[i] and pred_y[i] == 0) for i in range(len(pred_y))])
        FN = sum([(pred_y[i] != target_y[i] and pred_y[i] == 0) for i in range(len(pred_y))])
        print(TP + FP + TN + FN)
        Precision = TP / (TP + FP)
        Recall = TP / (TP + FN)
        F1 = 2 / (1 / Precision + 1 / Recall)
        print('F1: ', F1)

with torch.no_grad():
    net.eval()
    prediction = net(x_answer)
    print(prediction)
    result = torch.max(F.softmax(prediction), 1)[1]
    print(result)
    dictionary = {}
    dictionary['Index'] = [i for i in range(test_data.index[0], test_data.index[0] + len(test_data))]
    dictionary['Label'] = list(result.numpy())
    op = pd.DataFrame.from_dict(dictionary)
    print(op)
    op.to_csv("5_submission_1.csv", index=None)
