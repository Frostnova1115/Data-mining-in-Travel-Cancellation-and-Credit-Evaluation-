import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
import pandas as pd

device = (
    "cuda"
    if torch.cuda.is_available()
    else "mps"
    if torch.backends.mps.is_available()
    else "cpu"
)

print(device)

raw_data = pd.read_csv("train.csv", index_col='Index')
x_raw = torch.Tensor([list(raw_data.loc[i, 'Attr1':'Attr17']) for i in range(1, len(raw_data))])
y_raw = torch.Tensor([raw_data.loc[i, 'Label'] for i in range(1, len(raw_data))])

# n_data = torch.ones(10000, 2)
# x0 = torch.normal(2 * n_data, 1)
# y0 = torch.zeros(10000)
# # print(x0)
# x1 = torch.normal(-2 * n_data, 1)
# y1 = torch.ones(10000)

# x = torch.cat((x0, x1), 0).type(torch.FloatTensor)
# y = torch.cat((y0, y1)).type(torch.LongTensor)

x = x_raw.type(torch.FloatTensor)
y = y_raw.type(torch.LongTensor)
x, y = Variable(x), Variable(y)


class NN(torch.nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(NN, self).__init__()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(n_input, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_output),
        )

    def forward(self, input_x):
        logits = self.linear_relu_stack(input_x)
        return logits


epoch = 1000
net = NN(len(x[0]), 100, 2)
optimizer = torch.optim.Adam(net.parameters(), lr=0.02)
loss_func = torch.nn.CrossEntropyLoss()
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, epoch // 3, 0.5)

for t in range(epoch):
    prediction = net(x)
    loss = loss_func(prediction, y)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    scheduler.step()
    if t % 10 == 0:
        print(optimizer.param_groups[0]['lr'])
        result = torch.max(F.softmax(prediction), 1)[1]
        pred_y = result.data.numpy().squeeze()
        target_y = y.data.numpy()
        print(loss, end='')
        # print('accuracy: ', sum(pred_y == target_y) / len(y))
        TP = sum([(pred_y[i] == target_y[i] and pred_y[i] == 1) for i in range(len(pred_y))])
        FP = sum([(pred_y[i] != target_y[i] and pred_y[i] == 1) for i in range(len(pred_y))])
        TN = sum([(pred_y[i] == target_y[i] and pred_y[i] == 0) for i in range(len(pred_y))])
        FN = sum([(pred_y[i] != target_y[i] and pred_y[i] == 0) for i in range(len(pred_y))])
        print(TP + FP + TN + FN)
        Precision = TP / (TP + FP)
        Recall = TP / (TP + FN)
        F1 = 2 / (1 / Precision + 1 / Recall)
        print('F1: ', F1)
