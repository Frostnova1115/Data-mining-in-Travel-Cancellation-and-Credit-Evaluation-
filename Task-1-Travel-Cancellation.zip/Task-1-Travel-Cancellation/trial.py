# 1 import list
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn import ensemble


##############################################################
# decision_tree
def d_t():
    # 2 Data importation
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')

    # 定义决策树分类器
    decision_tree = DecisionTreeClassifier()

    # 定义参数集合
    param_grid = {
        'criterion': ['gini', 'entropy'],
        'splitter': ['best', 'random'],
        'max_depth': [None, 5, 10, 15, 20],
        'min_samples_split': [2, 5, 10, 15, 20],
        'min_samples_leaf': [1, 2, 4, 8],
        'max_features': [None, 'sqrt', 'log2'],
        'min_impurity_decrease': [0, 1, 2, 5, 10]
    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=decision_tree, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("decision tree best Parameters: ", grid_search.best_params_)


##############################################################
# KNN
def KNN():
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')
    knn = KNeighborsClassifier()

    # 定义参数集合
    param_grid = {
        'n_neighbors': [1, 5, 10, 15, 20, 25, 30, 35, 40],
        'weights': ['distance', 'uniform'],
        'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute'],
        'leaf_size': [25, 30, 35],
        'p': [1, 2, 4, 6, 8],
        'metric': ['minkowski'],
        'metric_params': [None],
        'n_jobs': [None]

    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=knn, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("KNN best Parameters: ", grid_search.best_params_)


##############################################################
# SVM
def SVM():
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')
    svm = SVC()

    # 定义参数集合
    param_grid = {
        'C': [0.3, 0.7, 1.0, 1.3, 1.7, 2.0],
        'kernel': ['rbf', 'poly', 'sigmoid'],
        'degree': [2, 3, 4, 5, 6, 7],
        'gamma': ['auto'],
        'coef0': [0.0, 0.3, 0.7, 1.0],
        'shrinking': [True, False],
        'probability': [True, False],
        'tol': [0.0005, 0.001, 0.005, 0.01],
        'cache_size': [100, 150, 200, 250, 300],
        'class_weight': [None, 0.3, 0.7, 1.0],
        'verbose': [True, False],
        'max_iter': [-1],
        'decision_function_shape': ['ovo', 'ovr', None],
        'random_state': [None]
    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=svm, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("SVM best Parameters: ", grid_search.best_params_)


##############################################################
# Bagging

def Bagging():
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')
    bagging = DecisionTreeClassifier()

    # 定义参数集合
    param_grid = {
        'numBaseClassifiers': [250, 500, 750, 1000, 1250],
        'max_samples': [50, 100, 150, 200, 250],
        'bootstrap': [True, None],
        'n_jobs': [-1, 1, 2, 4, 6, 8, 10],
        'val_oob_score': [True, None],
        'max_depth': [5, 10, 15, 20, 25]
    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=bagging, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("Bagging best Parameters: ", grid_search.best_params_)


##############################################################
# Adaboosting

def Adaboosting():
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')
    adaboosting = DecisionTreeClassifier()

    # 定义参数集合
    param_grid = {
        'numBaseClassifiers': [250, 500, 750, 1000],
        'max_depth': [5, 10, 15, 20, 25]
    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=adaboosting, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("Bagging best Parameters: ", grid_search.best_params_)


##############################################################
# Random Forest

def r_f():
    train = pd.read_csv('train.csv')
    test = pd.read_csv('test.csv')
    random_forest = ensemble.RandomForestClassifier()

    # 定义参数集合
    param_grid = {
        # 'numBaseClassifiers': [250, 500, 750, 1000],
        'criterion': ['gini', 'entropy'],
        'max_depth': [None],
        'min_samples_split': [2, 4, 6, 8],
        'min_samples_leaf': [1, 2, 4, 6, 8],
        'min_weight_fraction_leaf': [0.0, 0.25, 0.5, 0.75, 1.0],
        'max_features': ['auto', 'sqrt'],
        'max_leaf_nodes': [None],
        'bootstrap': [True, False],
        'oob_score': [True, False],
        'n_jobs': [1, 2, 4],
        'random_state': [None],
        'verbose': [0, 1, 2, 4, 6, 8],
        'warm_start': [True, False],
        'class_weight': [None]
    }
    # 5 set split
    train = train.iloc[1:]
    xtrain = train.drop('Label', axis=1)
    ytrain = train['Label']
    xtrain, xtest, ytrain, ytest = train_test_split(xtrain, ytrain, test_size=0.05)

    # 使用GridSearchCV进行参数搜索
    grid_search = GridSearchCV(estimator=random_forest, param_grid=param_grid, cv=5, scoring='accuracy')
    grid_search.fit(xtrain, ytrain)

    # 打印最佳参数
    print("Random forest best Parameters: ", grid_search.best_params_)

r_f()