import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import matplotlib.pyplot as plt
import pandas as pd
import torch.utils.data as Data

device = (
    "cuda"
    if torch.cuda.is_available()
    else "mps"
    if torch.backends.mps.is_available()
    else "cpu"
)

print(device)

raw_data = pd.read_csv("train.csv", index_col='Index')
x_raw = torch.Tensor([list(raw_data.loc[i, 'Attr1':'Attr17']) for i in range(1, len(raw_data))])
y_raw = torch.Tensor([raw_data.loc[i, 'Label'] for i in range(1, len(raw_data))])

# n_data = torch.ones(10000, 2)
# x0 = torch.normal(2 * n_data, 1)
# y0 = torch.zeros(10000)
# # print(x0)
# x1 = torch.normal(-2 * n_data, 1)
# y1 = torch.ones(10000)

# x = torch.cat((x0, x1), 0).type(torch.FloatTensor)
# y = torch.cat((y0, y1)).type(torch.LongTensor)

x = x_raw.type(torch.FloatTensor)
y = y_raw.type(torch.FloatTensor)
data_set = Data.TensorDataset(x, y)
train_weight = 0.9
train_size = int(len(data_set) * train_weight)
test_size = len(data_set) - train_size
training_set, test_set = Data.random_split(
    dataset=data_set,
    generator=torch.Generator().manual_seed(0),
    lengths=[train_size, test_size]
)

train_loader = Data.DataLoader(dataset=training_set, batch_size=128, shuffle=False)
test_loader = Data.DataLoader(dataset=test_set, batch_size=128, shuffle=False)


# x, y = Variable(x), Variable(y)


class NN(nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(NN, self).__init__()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(n_input, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_output),
            nn.Sigmoid()
        )

    def forward(self, input_x):
        logits = self.linear_relu_stack(input_x)
        return logits


epoch = 200
net = NN(len(x[0]), 100, 1)
optimizer = torch.optim.Adam(net.parameters(), lr=0.05)
# loss_func = torch.nn.CrossEntropyLoss()
loss_func = torch.nn.BCELoss()
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, epoch // 5, 0.5)

for t in range(epoch):
    net.train()
    for inputs, labels in train_loader:
        outputs = net(inputs)
        loss = loss_func(outputs, labels.view(-1, 1))
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    print(f'Epoch {t + 1}/{epoch}, Loss: {loss.item():.4f}')
    scheduler.step()

with torch.no_grad():
    net.eval()
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for inputs, labels in test_loader:
        outputs = net(inputs).data.numpy().squeeze()
        predict = (outputs.squeeze() > 0.5).astype(int)
        TP += sum([(predict[i] == 1 and labels[i] == 1) for i in range(len(predict))])
        FP += sum([(predict[i] == 1 and labels[i] == 0) for i in range(len(predict))])
        TN += sum([(predict[i] == 0 and labels[i] == 0) for i in range(len(predict))])
        FN += sum([(predict[i] == 0 and labels[i] == 1) for i in range(len(predict))])
    # print(TP+FP+TN+FN)
    Precision = TP / (TP + FP)
    Recall = TP / (TP + FN)
    F1 = 2 / (1 / Precision + 1 / Recall)
    print('F1: ', F1)
# accuracy = torch.sum(predictions == ytest_tensor.view(-1, 1)).item() / len(ytest_tensor)
# print(f'Accuracy on the test set: {accuracy * 100:.2f}%')
