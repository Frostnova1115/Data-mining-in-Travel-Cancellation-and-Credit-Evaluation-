# 1 import list

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import random
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn import tree
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn import ensemble
from sklearn.tree import DecisionTreeClassifier


# 2 Data importation

train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')


# 3 functions

def get_column_details(df, column):
    print("Details of",column)
    print("DataType: ",df[column].dtype)
    count_null = df[column].isnull().sum()
    if count_null == 0:
        print("There are no null values")
    elif count_null > 0:
        print("There are ",count_null," null values")
    print("Unique Values: ",df[column].unique())
    print("Distribution of column:")
    print(df[column].value_counts())
    # print(df[column].value_counts().to_string())
    return "~~~~Finished~~~~"


# 4 Data information

"""
print('')
print("****************")
print("* Data Preview *")
print("****************")
print('')

attribute_names_list = train.columns.tolist()
print('')
print("Attribute Information: ")

for i in attribute_names_list[1:-1]:
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("")
    print(get_column_details(train, i))
    #print(get_column_details(test, i))
    print("")
"""

print('')
print("*******************")
print("* Output Terminal *")
print("*******************")
print('')


# 5 set split
train = train.iloc[1:]
xtrain = train.drop('Label', axis=1)
ytrain = train['Label']
xtrain,xtest,ytrain,ytest = train_test_split(xtrain,
                                             ytrain,
                                             test_size=0.05)

###############################################################
# Variables

# Decision Tree
var_criterion = 'gini'           # 用于衡量分裂质量的准则，可选值为'gini'或'entropy'     %%
var_splitter = 'best'            # 用于选择分裂节点的策略，可选值为'best'或'random'     %%
var_max_depth = 10             # 树的最大深度，None表示不限制深度     %%
var_min_samples_split = 2           # 节点分裂所需的最小样本数     %%
var_min_samples_leaf = 4            # 叶节点所需的最小样本数     %%
var_min_weight_fraction_leaf = 0.0           # 叶节点样本权重的最小加权分数     %%
var_max_features = None                    # 在每次分裂时考虑的最大特征数，None表示考虑所有特征     %%
var_random_state = None                    # 控制决策树的随机性，提供一个整数种子保证可重复性
var_max_leaf_nodes = None                    # 最大叶节点数，None表示不限制叶节点数
var_min_impurity_decrease = 0.0                # 如果分裂导致不纯度减少大于或等于此值，则分裂节点     %%
val_class_weight = None                  # 类别权重，None表示所有类别的权重相同

# kNN
var_n_neighbors = 5        # like 1, 5, 10, 15, 20, 25, 30 ; default=5     %%
var_weights = 'uniform'    # ‘distance’: weight points by the inverse of their distance ; ‘uniform’: uniform weights.      %%
var_algorithm = 'auto'     # {‘auto’, ‘ball_tree’, ‘kd_tree’, ‘brute’},default=’auto’     %%
var_leaf_size = 30         # Leaf size passed to BallTree or KDTree.     %%
var_p = 2                  # Power parameter for the Minkowski metric. default= 2     %%
var_metric='minkowski'     # str or callable, default=’minkowski’     %%
var_metric_params=None     # if var_metric='minkowski' then metric_params == p
var_n_jobs=None            # ignore this #指定用於計算的 CPU 核心數目。設為 None 時表示使用所有可用的 CPU 核心。

# Bayes

# SVM
var_C = 1.0                        # Regularization parameter; default=1.0     %%
var_kernel = 'rbf'                 # Specifies the kernel type to be used in the algorithm; default='rbf'     %%
var_degree = 3                      # Degree of the polynomial kernel function; ignored by all other kernels; default=3     %%
var_gamma = 'auto'                  # Kernel coefficient for 'rbf', 'poly' and 'sigmoid'; default='auto'     %%
var_coef0 = 0.0                    # Independent term in kernel function; default=0.0     %%
var_shrinking = True                # Whether to use the shrinking heuristic; default=True     %%
var_probability = False             # Whether to enable probability estimates; default=False     %%
var_tol = 0.001                     # Tolerance for stopping criterion; default=0.001     %%
var_cache_size = 200                # Specify the size of the kernel cache; default=200     %%
var_class_weight = None             # Set the parameter C of class i to class_weight[i]*C for SVC; default=None
var_verbose = False                 # Enable verbose output; default=False
var_max_iter = -1                      # Hard limit on iterations within solver; default=-1 (unlimited)
var_decision_function_shape = 'ovo'  # Whether to return a one-vs-one ('ovo') or one-vs-the-rest ('ovr') decision function; default=None
var_random_state = None              # Controls the pseudo-random number generator; default=None


# Ensemble

# Bagging
numBaseClassifiers = 500            # Number of base classifiers to create an ensemble     %%
                                    # Example: 500 (integer)
val_max_samples = 100               # The number of samples to draw from X to train each base estimator     %%
                                    # Example: 100 (integer)
val_bootstrap = True                # Whether to use bootstrapped samples when building base classifiers     %%
                                    # Example: True or False (boolean)
val_n_jobs = -1                     # The number of jobs to run in parallel for base classifier training
                                    # Example: -1 (use all available processors), 1, 2, ...
val_oob_score = True                # Whether to use out-of-bag samples to estimate the generalization accuracy
                                    # Example: True or False (boolean)
model = DecisionTreeClassifier(max_depth=10)         # Base classifier model for bagging     %%     %%     %%     %%     %%
                                                     # Example: DecisionTreeClassifier(max_depth=10)

# Adaboosting
numBaseClassifiers2 = 500           # Number of base classifiers for Adaboosting     %%
                                    # Example: 500 (integer)
model2 = DecisionTreeClassifier(max_depth=10)         # Base classifier model for Adaboosting     %%     %%     %%     %%     %%
                                                      # Example: DecisionTreeClassifier(max_depth=10)

# Random Forest
numBaseClassifiers3 = 500           # Number of base classifiers for Random Forest     %%
                                    # Example: 500 (integer)
val_criterion = 'gini'              # The function to measure the quality of a split in each base classifier     %%
                                    # Example: 'gini' or 'entropy' (string)
val_max_depth = None                # The maximum depth of the base classifiers' decision trees     %%
                                    # Example: None (unlimited depth) or an integer
val_min_samples_split = 2           # The minimum number of samples required to split an internal node     %%
                                    # Example: 2 (integer)
val_min_samples_leaf = 1            # The minimum number of samples required to be at a leaf node     %%
                                    # Example: 1 (integer)
val_min_weight_fraction_leaf = 0.0         # The minimum weighted fraction of the sum total of weights     %%
                                          # Example: 0.0 (float)
val_max_features = 'auto'           # The number of features to consider when looking for the best split     %%
                                    # Example: 'auto' or 'sqrt' (string)
val_max_leaf_nodes = None            # Grow trees with max_leaf_nodes in the base classifiers     %%
                                    # Example: None (unlimited) or an integer
val_bootstrap = True                 # Whether to use bootstrapped samples when building base classifiers     %%
                                    # Example: True or False (boolean)
val_oob_score = False                # Whether to use out-of-bag samples to estimate the generalization accuracy
                                    # Example: True or False (boolean)
val_n_jobs = 1                      # The number of jobs to run in parallel for base classifier training
                                    # Example: 1, 2, ...
val_random_state = None              # Seed for random number generation in base classifiers     %%
                                    # Example: None or an integer
val_verbose = 0                      # Controls the verbosity when fitting base classifiers
                                    # Example: 0 (no output), 1, 2, ...
val_warm_start = False               # When set to True, reuse the solution of the previous call
                                    # Example: True or False (boolean)
val_class_weight = None              # Weights associated with classes in the form {class_label: weight}
                                    # Example: None or {0: 1, 1: 2} (dictionary)


###############################################################


# 6 Decision Tree

# 6.1 program
clf = tree.DecisionTreeClassifier(criterion=var_criterion,
                                  splitter=var_splitter,
                                  max_depth=var_max_depth,
                                  min_samples_split=var_min_samples_split,
                                  min_samples_leaf=var_min_samples_leaf,
                                  min_weight_fraction_leaf=var_min_weight_fraction_leaf,
                                  max_features=var_max_features,
                                  random_state=var_random_state,
                                  max_leaf_nodes=var_max_leaf_nodes,
                                  min_impurity_decrease=var_min_impurity_decrease,
                                  class_weight=val_class_weight)
clf.fit(xtrain,ytrain)     # input X,y for training
ypred = clf.predict(xtest)
Tree_score = classification_report(ytest, ypred, output_dict=True)['1']['f1-score']

# 6.2  output
ypred = pd.DataFrame(ypred)
ypred.to_csv('Decision_Tree.csv')
print("1. Decision Tree Finished")
print("   f1-score: ",Tree_score)
print("")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("")


# 7 kNN

# 7.1 program
clf = KNeighborsClassifier(n_neighbors=var_n_neighbors,
                            weights=var_weights,
                            algorithm=var_algorithm,
                            leaf_size=var_leaf_size,
                            p=var_p,
                            metric=var_metric,
                            metric_params=var_metric_params,
                            n_jobs=var_n_jobs)
clf.fit(xtrain, ytrain)
ypred = clf.predict(xtest)
kNN_score = classification_report(ytest, ypred, output_dict=True)['1']['f1-score']

# 7.2  output
ypred = pd.DataFrame(ypred)
ypred.to_csv('kNN.csv')
print("2. kNN Finished")
print("   f1-score: ",kNN_score)
print("")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("")


# 8 Bayes

# 8.1 program
gnb = GaussianNB()
gnb.fit(xtrain, ytrain)
gnb_ypred = clf.predict(xtest)
gnb_score = classification_report(ytest, gnb_ypred, output_dict=True)['1']['f1-score']

mnb = MultinomialNB()
mnb.fit(xtrain, ytrain)
mnb_ypred = clf.predict(xtest)
mnb_score = classification_report(ytest, mnb_ypred, output_dict=True)['1']['f1-score']

# 8.2  output
gnb_ypred = pd.DataFrame(gnb_ypred)
gnb_ypred.to_csv('Bayes_gnb.csv')
print("3a. Bayes_gnb Finished")
print("   f1-score: ",gnb_score)
print("")
mnb_ypred = pd.DataFrame(mnb_ypred)
mnb_ypred.to_csv('Bayes_mnb.csv')
print("3b. Bayes_mnb Finished")
print("   f1-score: ",mnb_score)
print("")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("")


# 9 SVM

# 9.1 program
clf = SVC(C=var_C,
          kernel=var_kernel,
          degree=var_degree,
          gamma=var_gamma,
          coef0=var_coef0,
          shrinking=var_shrinking,
          probability=var_probability,
          tol=var_tol,
          cache_size=var_cache_size,
          class_weight=var_class_weight,
          verbose=var_verbose,
          max_iter=var_max_iter,
          decision_function_shape=var_decision_function_shape,
          random_state=var_random_state)
clf.fit(xtrain, ytrain)
ypred = clf.predict(xtest)
SVM_score = classification_report(ytest, ypred, output_dict=True)['1']['f1-score']

# 9.2  output
ypred = pd.DataFrame(ypred)
ypred.to_csv('SVM.csv')
print("4. SVM Finished")
print("   f1-score: ",SVM_score)
print("")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("")


# 10  Ensemble

# 10.1 program
# Bagging
clf = ensemble.BaggingClassifier(model,
                                 n_estimators=numBaseClassifiers,
                                 bootstrap=val_bootstrap,
                                 n_jobs=val_n_jobs,
                                 oob_score=val_oob_score)
clf.fit(xtrain, ytrain)
Bagging_ypred = clf.predict(xtest)
Bagging_score = classification_report(ytest, Bagging_ypred, output_dict=True)['1']['f1-score']

# Boosting
clf = ensemble.AdaBoostClassifier(model2,
                                 n_estimators=numBaseClassifiers2)
clf.fit(xtrain, ytrain)
Boosting_ypred = clf.predict(xtest)
Boosting_score = classification_report(ytest, Boosting_ypred, output_dict=True)['1']['f1-score']

# Random forest
clf = ensemble.RandomForestClassifier(n_estimators=numBaseClassifiers3,
                                      criterion=val_criterion,
                                      max_depth=val_max_depth,
                                      min_samples_split=val_min_samples_split,
                                      min_samples_leaf=val_min_samples_leaf,
                                      min_weight_fraction_leaf=val_min_weight_fraction_leaf,
                                      max_features=val_max_features,
                                      max_leaf_nodes=val_max_leaf_nodes,
                                      bootstrap=val_bootstrap,
                                      oob_score=val_oob_score,
                                      n_jobs=val_n_jobs,
                                      random_state=val_random_state,
                                      verbose=val_verbose,
                                      warm_start=val_warm_start,
                                      class_weight=val_class_weight)
clf.fit(xtrain, ytrain)
rf_ypred = clf.predict(xtest)
rf_score = classification_report(ytest, rf_ypred, output_dict=True)['1']['f1-score']

# 10.2  output
Bagging_ypred = pd.DataFrame(Bagging_ypred)
Bagging_ypred.to_csv('Enb_Bagging.csv')
print("5a. Enb_Bagging Finished")
print("   f1-score: ",Bagging_score)
print("")

Boosting_ypred = pd.DataFrame(Boosting_ypred)
Boosting_ypred.to_csv('Enb_Boosting.csv')
print("5b. Enb_Boosting Finished")
print("   f1-score: ",Boosting_score)
print("")

rf_ypred = pd.DataFrame(rf_ypred)
rf_ypred.to_csv('Enb_Random_Forest.csv')
print("5c. Enb_Random_Forest Finished")
print("   f1-score: ",rf_score)
print("")
print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
print("")
print("*********************************")
print("* Finished - All model finished *")
print("*********************************")
print('')

